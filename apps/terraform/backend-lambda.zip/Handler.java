package com.example; public class Handler { public String handleRequest(Object input) { return "Hello from Lambda!"; } }
